/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include<iostream>
#include<conio.h>
using namespace std;

struct Promedio{
	float nota1;
	float nota2;
	float nota3;
};

struct Alumno{
	char nombre[20];
	char sexo[10];
	int edad;
	struct Promedio prom;
}alumno1;

int main(){
	float promedio_alumno;
	
	cout<<"Nombre: "; 
	cin.getline(alumno1.nombre,20,'\n');
	cout<<"Sexo: "; 
	cin.getline(alumno1.sexo,10,'\n');
	cout<<"Edad: "; 
	cin>>alumno1.edad;
	
	cout<<"\n.:Notas del Alumno:."<<endl;
	cout<<"Nota1: "; 
	cin>>alumno1.prom.nota1;
	cout<<"Nota2: "; 
	cin>>alumno1.prom.nota2;
	cout<<"Nota3: "; 
	cin>>alumno1.prom.nota3;
	
	//Sacando el promedio del alumno
	promedio_alumno = (alumno1.prom.nota1+alumno1.prom.nota2+alumno1.prom.nota3)/3;
	
	
	cout<<"\nMostrando Datos"<<endl;
	cout<<"Nombre: "<<alumno1.nombre<<endl;
	cout<<"Sexo: "<<alumno1.sexo<<endl;
	cout<<"Edad: "<<alumno1.edad<<endl;
	cout<<"Promedio: "<<promedio_alumno<<endl;
	
	
	getch();
	return 0;
}
