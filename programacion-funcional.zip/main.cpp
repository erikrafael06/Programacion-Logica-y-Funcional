/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <conio.h>
using namespace std; 
void ingreso( ); 
int suma(int,int); 
int resta(int,int); 
main() {  
ingreso(); 
getch(); 
}
 void ingreso( ) {
int a,b;
cout<<"Ingresa el primer numero : \t";
cin>>a;
cout<<"Ingresa el segundo numero : \t";
cin>>b; 
cout<<"**LOS RESULTADOS SON**"<<endl;
cout<<"El resultado de la suma es : "<<suma(a,b)<<endl;
cout<<"El resultado de la resta es : "<<resta(a,b)<<endl;
}
int suma(int f,int g){
return f+g;
}
int resta (int f,int g){
return f-g;
}
